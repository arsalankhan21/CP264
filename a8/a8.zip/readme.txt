JobID: cp264oc-a8-lab8
Name: Arsalan khan
ID: 210862640

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab8

T1 BST
T1.1 [2/2/*] Read and test BST example

T2 AVL trees
T2.1 [4/4/*] Read and test AVL examples

T3 Red-Black-tree
T3.1 [2/2/*] Read and test Red-Black-tree

T4 Splay trees
T4.1 [2/2/*] Read and test Splay tree

A8

Q1 AVL tree
Q1.1 [4/4/*] balance_factor(),is_avl()               
Q1.2 [3/3/*] rotate_left()                           
Q1.3 [3/3/*] rotate_right()                          
Q1.4 [5/5/*] insert()                                
Q1.5 [5/5/*] delete()                                

Q2 AVL tree for record data processing
Q2.1 [5/5/*] merge_tree()                            
Q2.2 [5/5/*] merge_data()                            

Total: [40/40/*]

Q1 output:
PS C:\Users\arsal\OneDrive\Desktop\cp264\a8> gcc avl.c avl_main.c -o q1                                   
PS C:\Users\arsal\OneDrive\Desktop\cp264\a8> ./q1                                                         
   
AVL insertions:
insert(&root, A, 1.0):
insert(&root, B, 2.0):
insert(&root, C, 3.0):
insert(&root, D, 4.0):
insert(&root, E, 5.0):
insert(&root, F, 6.0):
insert(&root, G, 7.0):
|___:D,4.0,3
    |___R:F,6.0,2
        |___R:G,7.0,1
        |___L:E,5.0,1
    |___L:B,2.0,2
        |___R:C,3.0,1
        |___L:A,1.0,1
is_val(&root):1
inorder:A B C D E F G 
AVL deletions:
delete(&root, A):
delete(&root, C):
delete(&root, E):
delete(&root, G):
|___:D,4.0,2
    |___R:F,6.0,1
    |___L:B,2.0,1
is_val(&root):1
inorder:B D F

PS C:\Users\arsal\OneDrive\Desktop\cp264\a8> 

Q2 output:
PS C:\Users\arsal\OneDrive\Desktop\cp264\a8> gcc queue_stack.c avl.c myrecord_avl.c myrecord_avl_main.c -o q2
PS C:\Users\arsal\OneDrive\Desktop\cp264\a8> ./q2                                                         
   
inport data from marks1.txt:
Bodnar,93.6
Chabot,80.4
Costa,45.1
Dabu,74.4
Giblett,59.1
Hatch,66.5
Myrie,76.7
Smith,60.1
Suglio,85.7
Sun,67.7
t1.count:10.0
t1.mean:70.9
t1.stddev:7.2

inport data from marks2.txt:
Ali,88.0
Allison,67.7
Eccles,77.8
He,85.7
Koreck,77.4
Lamont,98.1
Parr,92.5
Pereira,80.3
Peters,82.3
Wang,98.1
t2.count:10.0
t2.mean:84.8
t2.stddev:1.0

test merge data
Ali,88.0
Allison,67.7
Bodnar,93.6
Chabot,80.4
Costa,45.1
Dabu,74.4
Eccles,77.8
Giblett,59.1
Hatch,66.5
He,85.7
Koreck,77.4
Lamont,98.1
Myrie,76.7
Parr,92.5
Pereira,80.3
Peters,82.3
Smith,60.1
Suglio,85.7
Sun,67.7
Wang,98.1
merge.count:20.0
merge.mean:77.9
merge.stddev:16.3

test process data
stats.count:20.0
stats.mean:77.9
stats.stddev:13.5
stats.median:79.1

PS C:\Users\arsal\OneDrive\Desktop\cp264\a8> 

