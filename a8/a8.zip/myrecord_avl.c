/*
-------------------------------------------------------
Project:  cp264oc-a8q1
Author:   Arsalan Khan
Version:  2023-07-15
-------------------------------------------------------
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "avl.h"
#include "queue_stack.h"
#include "myrecord_avl.h"
#include <math.h>

void merge_tree(TNODE **rootp1, TNODE **rootp2) {
    if (*rootp2 == NULL)
        return;

    insert(rootp1, (*rootp2)->data.name, (*rootp2)->data.score);

    merge_tree(rootp1, &((*rootp2)->left));
    merge_tree(rootp1, &((*rootp2)->right));
}

void merge_data(TREE *t1, TREE *t2) {
    merge_tree(&(t1->root), &(t2->root));

    float totalCount = t1->count + t2->count;
    t1->mean = ((t1->mean * t1->count) + (t2->mean * t2->count)) / totalCount;
    t1->stddev = sqrt(((pow(t1->stddev, 2) * t1->count) +
                       (pow(t2->stddev, 2) * t2->count) +
                       (pow(t1->mean - t2->mean, 2) * t1->count * t2->count)) / totalCount);
    t1->count = totalCount;
}

void add_data(TREE *tree, char *name, float score) {
    TNODE *node = search(tree->root, name);
    if (node != NULL) {
        printf("Error: Record with name '%s' already exists.\n", name);
        return;
    }

    insert(&(tree->root), name, score);
    tree->count++;
    float sum = tree->mean * (tree->count - 1);
    tree->mean = (sum + score) / tree->count;
    tree->stddev += pow(score - tree->mean, 2);
    tree->stddev = sqrt(tree->stddev / tree->count);
}

void remove_data(TREE *tree, char *name) {
    TNODE *node = search(tree->root, name);
    if (node == NULL) {
        printf("Error: Record with name '%s' does not exist.\n", name);
        return;
    }

    delete(&(tree->root), name);
    tree->count--;
    float sum = tree->mean * (tree->count + 1);
    tree->mean = (sum - node->data.score) / tree->count;
    tree->stddev -= pow(node->data.score - tree->mean, 2);
    tree->stddev = sqrt(tree->stddev / tree->count);
}
