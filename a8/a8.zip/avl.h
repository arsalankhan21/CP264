/*
-------------------------------------------------------
Project:  cp264oc-a8q1
Author:   Arsalan Khan
Version:  2023-07-15
-------------------------------------------------------
*/
#ifndef AVL_H
#define AVL_H

typedef struct record {
  char name[40];
  float score;
} RECORD;

typedef struct tnode {
  RECORD data;
  int height;
  struct tnode *left;
  struct tnode *right;
} TNODE;

int balance_factor(TNODE *root);
int is_avl(TNODE *root);
TNODE *rotate_left(TNODE *root);
TNODE *rotate_right(TNODE *root);
void insert(TNODE **rootp, char *name, float score);
void delete(TNODE **rootp, char *name);
TNODE *search(TNODE *root, char *name);
void clean_tree(TNODE **rootp);
TNODE *extract_smallest_node(TNODE **rootp); // Function declaration added

#endif
