/*
--------------------------------------------------
Project: cp264oc-a3q1
File:    mystring.c
About:   string functions
Author:  Arsalan Khan
ID:      210862640
Version: 2023-06-02
--------------------------------------------------
*/

#include <stdio.h>
#include "mystring.h"
#include <stdbool.h>
#include <ctype.h>

int str_len(char *s) {
    int count = 0; //Setting a count variable to zero 
    for (; *s != '\0'; s++) { // Sets a for loop
        count++;
    }

    return count;
}

int str_wc(char *s) {
    int count = 0; 
    bool word_check = false; 

    for (; *s != '\0'; s++) {

        if (*s == ' '|| *s == '\t' || *s == '\n') {
        word_check = false;    
        }
        else if (!word_check) {
            word_check = true; 
            count++;
        }

    }

    return count;

}

void str_lower(char *s) {
    for (int i = 0; s[i] != '\0'; i++) {
        s[i] = tolower(s[i]);
    }
}

void str_trim(char* s) {
    if (s == NULL) {
        return; // Handle NULL input
    }
    
    char *p = s, *dp = s;
    
    // Skip leading whitespace characters
    while (*p && *p == ' ') { // While *p is not null and *p is whitespace
        p++; //keep moving
    }
    
    // Check if the string is empty or consists entirely of whitespace characters
    if (*p == '\0') {
        *s = '\0'; // Set the first character to null to create an empty string
        return;
    }
    
    // Copy non-leading whitespace characters and reduce consecutive whitespace to a single space
    while (*p) {
        if (*p != ' ' || (p > s && *(p - 1) != ' ')) {
            *dp = *p;
            dp++;
        }
        p++;
    }

    if (*(dp - 1) == ' ') {
        dp--;
    }
    
    *dp = '\0'; // Null-terminate the resulting trimmed string
}
