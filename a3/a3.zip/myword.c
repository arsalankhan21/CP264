#include <stdio.h>
#include <string.h>
#include "mystring.h"
#include "myword.h"

void stopword_dictionary(char *filename, char *stopwords[])
{
    FILE *fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Error opening stopword file.\n");
        return;
    }

    char line[1000];
    char delimiters[] = " .,\n\t\r";
    char *token;
    int i;

    while (fgets(line, 1000, fp) != NULL) {
        token = strtok(line, delimiters);
        while (token != NULL) {
            i = (int)(*token - 'a');
            strcat(stopwords[i], token);
            strcat(stopwords[i], ",");
            token = strtok(NULL, delimiters);
        }
    }

    fclose(fp);
}

int is_stopword(char *stopwords[], char *word) {
    if (word == NULL || *word == '\0') return 0;
    else {
        char temp[20] = {0};
        strcat(temp, ",");
        strcat(temp, word);
        strcat(temp, ",");
        if (strstr(stopwords[*word - 'a'], temp) != NULL)
            return 1;
        else
            return 0;
    }
}

int process_word(char *filename, WORDSUMMARY *words, char *stopwords[]) {
    FILE *fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Error opening text file.\n");
        return -1;
    }

    char line[MAX_LINE_LEN];
    char delimiters[] = " .,\n\t\r";
    char *word_token;

    while (fgets(line, MAX_LINE_LEN, fp) != NULL) {
        words->line_count++;
        str_lower(line);
        str_trim(line);
        word_token = strtok(line, delimiters);
        
        while (word_token != NULL) {
            int found = is_stopword(stopwords, word_token);
            if (!found) {
                int word_found = 0;
                for (int i = 0; i < words->non_common_word_count; i++) {
                    if (strcmp(words->word_array[i].word, word_token) == 0) {
                        words->word_array[i].frequency++;
                        word_found = 1;
                        break;
                    }
                }
                if (!word_found) {
                    strcpy(words->word_array[words->non_common_word_count].word, word_token);
                    words->word_array[words->non_common_word_count].frequency = 1;
                    words->non_common_word_count++;
                }
            }
            words->word_count++;  // Increment word count
            word_token = strtok(NULL, delimiters);
        }
    }

    fclose(fp);
    return 0;
}
