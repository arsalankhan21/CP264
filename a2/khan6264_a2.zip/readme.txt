JobID: cp264oc-a2-lab2
Name: Arsalan Khan 
ID: 210862640

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab2

T1 C Debugging
T1.1 [2/2/*] Debug under command line
T1.2 [2/2/*] Debug under Eclipse

T2 Pointers
T2.1 [2/2/*] Test on pointers

T3 Arrays
T3.1 [2/2/*] Test on arrays

T4 2D Arrays
T4.1 [2/2/*] Test on 2D arrays

A2

Q1 Computing Fibonacci numbers
Q1.1 [0/2/*] iterative_fibonacci()                   
Q1.2 [0/2/*] recursive_fibonacci()                   
Q1.3 [0/2/*] dpbu_fibonacci()                        
Q1.4 [0/2/*] dptd_fibonacci()                        

Q2 Array & polynomial
Q2.1 [0/5/*] horner()                                
Q2.2 [0/5/*] bisection()                             

Q3 Vector and Matrix
Q3.1 [0/2/*] sum()                                   
Q3.2 [0/2/*] norm()                                  
Q3.3 [0/2/*] dot_product()                           
Q3.4 [0/2/*] transpose_matrix()                      
Q3.5 [0/2/*] multiply_matrix()                       
Q3.6 [0/2/*] matrix_multiply_vector()                

Total: [0/40/*]

